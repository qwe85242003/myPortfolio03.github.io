// aryImg 定義圖片陣列
// aryText 定義文字陣列
// noImg 圖片id名稱
// noText 文字id名稱
// 注意變更sImg 圖片實體資料路徑

<script language="javascript">
	$(function(){			
		autonext()	 
	});

	var page=0;
	var sImg,sText;

	var aryImg = new Array("iphone01.png","iphone02.png","iphone03.png","iphone04.png","iphone05.png","iphone06.png");   //0~5
	var aryText = new Array("iPhone XR 64GB Yellow","iPhone 8 Plus 64GB Space Grey","iPhone X 64GB Space Grey","iPhone 6","iPhone 7","iPhone 7 plus");  //0~5

	function autonext(){ //下一頁method
		setInterval(function(){
			page++;
		if (page>5) {page=0}
			sImg="img/"+aryImg[page];
			sText=aryText[page];
			$("#noImg").attr("src",sImg);
			$("#noText").text(sText);
		},2000)			
	}
</script>